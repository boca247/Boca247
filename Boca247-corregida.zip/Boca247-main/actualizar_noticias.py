#!/usr/bin/env python3
"""Compatibilidad: el sincronizador completo ahora vive en actualizar_datos.py."""
from actualizar_datos import main

if __name__ == "__main__":
    main()
