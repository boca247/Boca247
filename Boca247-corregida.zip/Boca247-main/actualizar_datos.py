#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BOCA 24/7 — sincronizador de datos deportivos y multimedia.

Fuentes:
- ESPN API pública: resultados, partidos y posiciones de Liga Profesional.
- Google News RSS: noticias.
- YouTube RSS: publicaciones del canal oficial de Boca Juniors.

El script está pensado para ejecutarse desde GitHub Actions cada 30 minutos.
Si una fuente falla, conserva el último dato válido para no romper el sitio.
"""

import json
import os
import re
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from xml.etree import ElementTree as ET
from zoneinfo import ZoneInfo

import requests

ROOT = os.path.dirname(os.path.abspath(__file__))
TZ = ZoneInfo("America/Argentina/Buenos_Aires")
NOW = datetime.now(TZ)

ESPN_SCOREBOARD = "https://site.api.espn.com/apis/site/v2/sports/soccer/arg.1/scoreboard"
ESPN_STANDINGS = "https://site.api.espn.com/apis/v2/sports/soccer/leagues/arg.1/standings"
GOOGLE_NEWS = "https://news.google.com/rss/search"
YOUTUBE_FEED = "https://www.youtube.com/feeds/videos.xml?channel_id=UClxxdaYCyZxW8TVg7SMXZLQ"

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; Boca247Bot/1.0)"}
TIMEOUT = 20


def get_json(url, params=None):
    r = requests.get(url, params=params, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def get_text(url, params=None):
    r = requests.get(url, params=params, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    r.encoding = "utf-8"
    return r.text


def load_json(name, default):
    path = os.path.join(ROOT, name)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(name, data):
    path = os.path.join(ROOT, name)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


def iso_now():
    return NOW.isoformat(timespec="seconds")


def clean(text):
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", str(text))
    return re.sub(r"\s+", " ", text).strip()


def parse_rfc_date(value):
    try:
        return parsedate_to_datetime(value).astimezone(TZ).isoformat(timespec="seconds")
    except Exception:
        return iso_now()


def team_name(comp):
    return clean((comp.get("team") or {}).get("displayName") or (comp.get("team") or {}).get("shortDisplayName"))


def parse_event(event):
    comp = (event.get("competitions") or [{}])[0]
    competitors = comp.get("competitors") or []
    home = next((x for x in competitors if x.get("homeAway") == "home"), competitors[0] if competitors else {})
    away = next((x for x in competitors if x.get("homeAway") == "away"), competitors[1] if len(competitors) > 1 else {})
    status = ((comp.get("status") or {}).get("type") or {})
    venue = (comp.get("venue") or {}).get("fullName") or ""
    city = (((comp.get("venue") or {}).get("address") or {}).get("city")) or ""
    state = status.get("name") or ""
    detail = status.get("shortDetail") or status.get("detail") or state
    return {
        "id": str(event.get("id") or ""),
        "fecha_iso": event.get("date") or iso_now(),
        "hora": (event.get("date") or "")[11:16] or "A confirmar",
        "equipo_local": team_name(home),
        "equipo_visitante": team_name(away),
        "goles_local": home.get("score"),
        "goles_visitante": away.get("score"),
        "estado": state or "PROGRAMADO",
        "detalle_estado": detail,
        "torneo": clean(((event.get("league") or {}).get("name")) or "Liga Profesional"),
        "estadio": venue,
        "ciudad": city,
        "periodo": (comp.get("status") or {}).get("period"),
        "reloj": (comp.get("status") or {}).get("displayClock"),
        "link": "https://www.espn.com.ar/futbol/partido/_/juegoId/" + str(event.get("id") or "")
    }


def is_boca(game):
    s = (game.get("equipo_local", "") + " " + game.get("equipo_visitante", "")).lower()
    return "boca" in s


def fetch_boca_games():
    events = []
    for offset in range(-3, 22):
        d = NOW.date() + timedelta(days=offset)
        try:
            data = get_json(ESPN_SCOREBOARD, {"dates": d.strftime("%Y%m%d")})
            for ev in data.get("events", []):
                game = parse_event(ev)
                if is_boca(game):
                    events.append(game)
        except Exception as e:
            print("ESPN scoreboard:", d, e)
    events.sort(key=lambda x: x.get("fecha_iso", ""))
    return events


def fetch_standings():
    data = get_json(ESPN_STANDINGS, {"region": "ar", "lang": "es", "contentorigin": "espn"})
    rows = []
    # ESPN ha cambiado el envoltorio de standings en distintas versiones.
    groups = []
    for child in data.get("children", []):
        groups.extend(child.get("standings", {}).get("entries", []))
        for sub in child.get("children", []):
            groups.extend(sub.get("standings", {}).get("entries", []))
    if not groups:
        groups = data.get("standings", {}).get("entries", [])

    for pos, entry in enumerate(groups, 1):
        team = entry.get("team") or {}
        stats = {s.get("name"): s.get("value") for s in entry.get("stats", [])}
        name = clean(team.get("displayName") or team.get("name"))
        if not name:
            continue
        rows.append({
            "posicion": int(stats.get("rank") or pos),
            "equipo": name,
            "pj": int(stats.get("gamesPlayed") or stats.get("played") or 0),
            "g": int(stats.get("wins") or 0),
            "e": int(stats.get("ties") or stats.get("draws") or 0),
            "p": int(stats.get("losses") or 0),
            "gf": int(stats.get("pointsFor") or stats.get("goalsFor") or 0),
            "gc": int(stats.get("pointsAgainst") or stats.get("goalsAgainst") or 0),
            "dif": int(stats.get("pointDifferential") or stats.get("goalDifference") or 0),
            "pts": int(stats.get("points") or 0)
        })
    return rows


def fetch_news():
    params = {
        "q": "Boca Juniors",
        "hl": "es-419",
        "gl": "AR",
        "ceid": "AR:es-419",
    }
    xml = get_text(GOOGLE_NEWS, params)
    root = ET.fromstring(xml)
    out = []
    for item in root.findall(".//item")[:30]:
        title = clean(item.findtext("title"))
        link = item.findtext("link") or ""
        desc = clean(item.findtext("description"))
        pub = item.findtext("pubDate") or ""
        source = clean(item.findtext("source")) or "Google Noticias"
        if not title:
            continue
        low = title.lower()
        cat = "FÚTBOL"
        mapping = {
            "COPA SUDAMERICANA": ["sudamericana", "são paulo", "sao paulo", "san pablo"],
            "COPA ARGENTINA": ["copa argentina", "vélez", "velez"],
            "TORNEO CLAUSURA": ["clausura", "gimnasia", "lanús", "lanus"],
            "PLANTEL": ["lesión", "lesion", "entrenamiento", "formación", "formacion"],
            "INSTITUCIONAL": ["riquelme", "club", "presidente"],
            "FEMENINO": ["femenino", "gladiadoras"],
            "BÁSQUET": ["básquet", "basquet"],
            "FUTSAL": ["futsal"],
        }
        for k, words in mapping.items():
            if any(w in low for w in words):
                cat = k
                break
        out.append({
            "titulo": title,
            "fuente": source,
            "contenido": desc[:350] if desc else "Última información del mundo Xeneize.",
            "link": link,
            "categoria": cat,
            "fecha_iso": parse_rfc_date(pub),
        })
    return {"actualizado": iso_now(), "noticias": out}


def fetch_videos():
    xml = get_text(YOUTUBE_FEED)
    root = ET.fromstring(xml)
    ns = {"yt": "http://www.youtube.com/xml/schemas/2015", "media": "http://search.yahoo.com/mrss/"}
    out = []
    for entry in root.findall("{http://www.w3.org/2005/Atom}entry")[:12]:
        title = clean(entry.findtext("{http://www.w3.org/2005/Atom}title"))
        published = entry.findtext("{http://www.w3.org/2005/Atom}published") or iso_now()
        vid = entry.findtext("{http://www.youtube.com/xml/schemas/2015}videoId")
        if not vid or not title:
            continue
        lower = title.lower()
        tipo = "ENTREVISTA" if any(x in lower for x in ["entrevista", "declaraciones", "conferencia"]) else "VIDEO"
        out.append({
            "titulo": title,
            "descripcion": "Contenido publicado por el canal oficial de Boca Juniors.",
            "link": f"https://www.youtube.com/watch?v={vid}",
            "duracion": "VIDEO",
            "tipo": tipo,
            "fecha_iso": published,
        })
    return out


def main():
    partidos = load_json("partidos.json", {})
    noticias = load_json("noticias.json", {})

    games = fetch_boca_games()
    if games:
        past = [g for g in games if g.get("goles_local") is not None and g.get("goles_visitante") is not None]
        future = [g for g in games if g not in past]

        if past:
            last = past[-1]
            partidos["ultimo_resultado"] = {
                "rival": last["equipo_visitante"] if "Boca" in last["equipo_local"] else last["equipo_local"],
                "competencia": last["torneo"],
                "fecha": last["fecha_iso"][:10],
                "resultado": f'{last["equipo_local"]} {last["goles_local"]} - {last["goles_visitante"]} {last["equipo_visitante"]}',
                "estado": last["estado"],
                "detalle_estado": last.get("detalle_estado", ""),
                "link": last.get("link", ""),
            }

        if future:
            nxt = future[0]
            partidos["partido_actual"] = {
                "rival": nxt["equipo_visitante"] if "Boca" in nxt["equipo_local"] else nxt["equipo_local"],
                "competencia": nxt["torneo"],
                "instancia": nxt.get("detalle_estado", ""),
                "fecha": nxt["fecha_iso"][:10],
                "hora": nxt["hora"],
                "estadio": nxt["estadio"],
                "ciudad": nxt["ciudad"],
                "estado": nxt["estado"],
                "link": nxt["link"],
            }

        partidos["partidos"] = games
        partidos["actualizado"] = iso_now()

    try:
        standings = fetch_standings()
        if standings:
            partidos["tabla"] = standings
            partidos["tabla_actualizada"] = iso_now()
    except Exception as e:
        print("ESPN standings:", e)

    try:
        n = fetch_news()
        if n["noticias"]:
            noticias.update(n)
            save_json("noticias.json", noticias)
    except Exception as e:
        print("Google News:", e)

    try:
        videos = fetch_videos()
        if videos:
            noticias["videos"] = videos
            save_json("noticias.json", noticias)
    except Exception as e:
        print("YouTube RSS:", e)

    save_json("partidos.json", partidos)
    print("BOCA 24/7 actualizado:", iso_now())


if __name__ == "__main__":
    main()
