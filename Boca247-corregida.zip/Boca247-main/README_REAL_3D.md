# BOCA 24/7 — portal 3D + datos dinámicos

Esta versión conserva la portada visual 3D y agrega una capa de datos deportivos reales.

## Qué se agregó

- Resultados y próximos partidos sincronizados desde ESPN.
- Tabla de posiciones de la Zona A del Torneo Clausura.
- Último resultado de Boca y próximo partido.
- Estado de partido en vivo cuando ESPN lo publica.
- Noticias actualizadas desde Google News RSS.
- Videos del canal oficial de Boca mediante feed RSS de YouTube.
- Actualización automática del repositorio cada 30 minutos con GitHub Actions.
- Actualización automática de las páginas en el navegador cada 30 minutos.
- La portada conserva la estructura, imágenes y estética 3D existentes.

## Archivos importantes

- `index.html`: portada 3D.
- `posiciones.html`: agenda, resultados y tabla dinámica.
- `multimedia.html`: streaming y videos/entrevistas.
- `partidos.json`: datos deportivos.
- `noticias.json`: noticias y multimedia.
- `actualizar_datos.py`: sincronizador.
- `.github/workflows/actualizar-noticias.yml`: tarea automática cada 30 minutos.

## Importante sobre "tiempo real"

La web no inventa resultados. El repositorio se actualiza automáticamente cada 30 minutos y la interfaz vuelve a leer los datos cada 30 minutos. Para un seguimiento segundo a segundo durante un partido se necesitaría contratar/conectar una API deportiva con licencia de datos live; esta versión deja la arquitectura preparada para incorporarla sin rediseñar la página.

Las fuentes deportivas y multimedia pueden cambiar sus formatos o limitar el acceso, por lo que el script conserva el último dato válido si una fuente temporalmente falla.
