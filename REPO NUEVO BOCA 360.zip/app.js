/* BOCA 24/7 — app.js
 * Lógica de frontend consolidada. Un solo archivo, linkeado en las 5 páginas.
 * Cada función chequea si sus elementos existen antes de correr, así este
 * mismo archivo sirve para index.html, noticias.html, plantel.html,
 * posiciones.html y multimedia.html sin duplicar código entre ellas.
 */

/* ---------- Utilidades comunes ---------- */
const $ = s => document.querySelector(s);

const esc = s => String(s ?? '').replace(/[&<>"']/g, m => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
}[m]));
// alias histórico usado en el bloque de posiciones
const escP = esc;

const fmtDate = s => {
  const d = new Date(s);
  return isNaN(d) ? '' : d.toLocaleDateString('es-AR', { day: '2-digit', month: 'short' }).toUpperCase();
};
const fmtP = s => {
  const d = new Date(s);
  return isNaN(d) ? (s || '') : d.toLocaleDateString('es-AR', { day: '2-digit', month: 'short' });
};

/* ---------- Reloj (noticias.html, plantel.html, posiciones.html, multimedia.html) ---------- */
function initClock() {
  const el = document.getElementById('clock');
  if (!el) return;
  const tick = () => {
    const d = new Date();
    el.textContent = 'Hora local: ' + d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
  };
  tick();
  setInterval(tick, 30000);
}

/* ---------- Menú hamburguesa (index.html) ---------- */
function initHamburger() {
  const btn = document.querySelector('.hamb');
  const nav = document.querySelector('nav');
  if (!btn || !nav) return;
  btn.onclick = () => nav.classList.toggle('open');
}

/* ---------- Efecto tilt en tarjetas (index.html) ---------- */
function initTilt() {
  document.querySelectorAll('[data-tilt]').forEach(el => {
    el.addEventListener('pointermove', e => {
      if (innerWidth < 800) return;
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      el.style.transform = `perspective(1100px) rotateX(${y * -7}deg) rotateY(${x * 7}deg) translateZ(6px)`;
    });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });
}

/* ---------- Countdown al próximo partido (index.html) ---------- */
function startCountdown(iso) {
  const target = new Date(iso);
  const tick = () => {
    let x = target - Date.now();
    if (x < 0) { $('#countdown').textContent = 'EN VIVO / FINALIZADO'; return; }
    const d = Math.floor(x / 864e5); x %= 864e5;
    const h = Math.floor(x / 36e5); x %= 36e5;
    const m = Math.floor(x / 6e4); x %= 6e4; // fix: antes los segundos no se acotaban a 0-59
    const s = Math.floor(x / 1e3);
    $('#countdown').textContent = `${String(d).padStart(2, '0')}D ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };
  tick();
  setInterval(tick, 1000);
}

/* ---------- Datos de la portada (index.html) ---------- */
async function loadHomeData() {
  if (!$('#ticker')) return; // solo corre en index.html
  const setTicker = (items) => {
    const text = items.map(n => `${n.categoria} · ${n.titulo}`).join('   ◆   ');
    $('#ticker').textContent = text + '   ◆   ' + text;
  };
  try {
    const [nr, pr] = await Promise.all([
      fetch('noticias.json?v=' + Date.now()),
      fetch('partidos.json?v=' + Date.now())
    ]);
    const data = await nr.json(), games = await pr.json();

    setTicker((data.noticias || []).slice(0, 5));

    const list = $('#newsList');
    list.innerHTML = (data.noticias || []).slice(1, 5).map(n =>
      `<a class="news-row" href="${esc(n.link || '#')}" target="_blank" rel="noopener"><div class="row-date">${fmtDate(n.fecha_iso)}<span>${esc(n.categoria)}</span></div><div><h3>${esc(n.titulo)}</h3><p>${esc(n.contenido)}</p></div><b>→</b></a>`
    ).join('');

    const p = games.partido_actual || {};
    if (p.rival) $('#rival').textContent = String(p.rival).toUpperCase();
    if (p.competencia) $('#competition').textContent = String(p.competencia).toUpperCase();
    if (p.fecha && p.hora && p.hora !== 'A confirmar') {
      $('#nextDate').textContent = new Date(p.fecha + 'T' + p.hora + ':00-03:00').toLocaleDateString('es-AR', { day: '2-digit', month: 'short' }).toUpperCase() + ' · ' + p.hora;
      startCountdown(p.fecha + 'T' + p.hora + ':00-03:00');
    }

    const last = games.ultimo_resultado;
    if (last) {
      $('#lastResult').textContent = String(last.resultado || '').toUpperCase();
      $('#lastCompetition').textContent = (last.fecha || '') + ' · ' + String(last.competencia || '').toUpperCase();
    }

    const live = (games.partidos || []).find(x =>
      String(x.estado).toUpperCase().includes('LIVE') ||
      String(x.estado).toUpperCase().includes('EN VIVO') ||
      String(x.estado).toUpperCase().includes('IN_PROGRESS')
    );
    if (live) {
      $('#liveState').textContent = 'EN VIVO';
      $('#liveDetail').textContent = `${live.equipo_local} ${live.goles_local ?? 0} — ${live.goles_visitante ?? 0} ${live.equipo_visitante} · ${live.reloj || live.detalle_estado || ''}`;
    } else {
      $('#liveState').textContent = 'DATOS DEPORTIVOS';
      $('#liveDetail').textContent = 'No hay un partido de Boca en juego en este momento';
    }

    const updated = games.actualizado || games.tabla_actualizada || data.actualizado;
    if (updated) $('#dataUpdated').textContent = 'Última sincronización: ' + new Date(updated).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' });
  } catch (e) { console.warn(e); }
}

/* ---------- Datos de agenda / resultados / tabla (posiciones.html) ---------- */
async function loadPosicionesData() {
  const cont = document.getElementById('agendaContainer');
  if (!cont) return; // solo corre en posiciones.html
  try {
    const r = await fetch('partidos.json?v=' + Date.now());
    const d = await r.json();
    const games = d.partidos || [];
    const next = games.filter(x => new Date(x.fecha_iso) > new Date()).slice(0, 8);
    const recent = games.filter(x => new Date(x.fecha_iso) <= new Date()).reverse().slice(0, 8);
    const live = games.find(x => /LIVE|IN.?PROGRESS|EN VIVO/i.test(x.estado || ''));

    document.getElementById('agendaContainer').innerHTML = next.length
      ? `<table class="dynamic-table"><thead><tr><th>FECHA</th><th>DISCIPLINA</th><th>PARTIDO</th><th>COMPETENCIA</th><th>ESTADO</th></tr></thead><tbody>${next.map(x => `<tr><td>${fmtP(x.fecha_iso)} · ${escP(x.hora)}</td><td>FÚTBOL</td><td><b>${escP(x.equipo_local)}</b> vs. <b>${escP(x.equipo_visitante)}</b></td><td>${escP(x.torneo)}</td><td>${escP(x.estado)}</td></tr>`).join('')}</tbody></table>`
      : '<p>No hay próximos partidos cargados.</p>';

    document.getElementById('resultadosContainer').innerHTML = recent.length
      ? `<table class="dynamic-table"><thead><tr><th>FECHA</th><th>PARTIDO</th><th>RESULTADO</th><th>COMPETENCIA</th><th>ESTADO</th></tr></thead><tbody>${recent.map(x => `<tr><td>${fmtP(x.fecha_iso)}</td><td>${escP(x.equipo_local)} vs. ${escP(x.equipo_visitante)}</td><td><b>${x.goles_local ?? '-'} — ${x.goles_visitante ?? '-'}</b></td><td>${escP(x.torneo)}</td><td>${escP(x.estado)}</td></tr>`).join('')}</tbody></table>`
      : '<p>No hay resultados recientes.</p>';

    const tabla = d.tabla || [];
    document.getElementById('tablaContainer').innerHTML = tabla.length
      ? `<table class="dynamic-table"><thead><tr><th>#</th><th>EQUIPO</th><th>PJ</th><th>G</th><th>E</th><th>P</th><th>GF</th><th>GC</th><th>DG</th><th>PTS</th></tr></thead><tbody>${tabla.map(x => `<tr class="${/Boca/i.test(x.equipo) ? 'boca-row' : ''}"><td>${x.posicion}</td><td>${escP(x.equipo)}</td><td>${x.pj}</td><td>${x.g}</td><td>${x.e}</td><td>${x.p}</td><td>${x.gf || '-'}</td><td>${x.gc || '-'}</td><td>${x.dif > 0 ? '+' : ''}${x.dif}</td><td class="pts">${x.pts}</td></tr>`).join('')}</tbody></table>`
      : '<p>No se pudo cargar la tabla.</p>';

    const up = d.actualizado || d.tabla_actualizada;
    document.getElementById('posUpdated').textContent = up ? 'Última sincronización: ' + new Date(up).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) : 'Sin fecha';
    document.getElementById('tablaUpdated').textContent = up ? 'Tabla actualizada: ' + new Date(up).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) : 'Actualización automática cada 30 minutos';
    document.getElementById('posTicker').textContent = live
      ? `EN VIVO · ${live.equipo_local} ${live.goles_local ?? 0} — ${live.goles_visitante ?? 0} ${live.equipo_visitante} · ${live.reloj || live.estado}`
      : `BOCA 24/7 · Último resultado: ${d.ultimo_resultado?.resultado || 'sin datos'} · Próximo: ${d.partido_actual?.rival || 'sin datos'}`;
  } catch (e) { console.error(e); }
}

/* ---------- Encuesta "Termómetro del hincha" (multimedia.html) ---------- */
let votes = [0, 0, 0, 0];
function vote(btn, i) {
  votes[i]++;
  const total = votes.reduce((a, b) => a + b, 0);
  votes.forEach((v, idx) => {
    const pct = total ? Math.round(v / total * 100) : 0;
    document.getElementById('pct' + idx).textContent = pct + '%';
    document.querySelectorAll('.poll-opt')[idx].querySelector('.fill').style.width = pct + '%';
  });
}

/* ---------- Videos dinámicos (multimedia.html) ---------- */
async function loadMultimediaVideos() {
  const el = document.getElementById('videosDynamic');
  if (!el) return; // solo corre en multimedia.html
  try {
    const r = await fetch('noticias.json?v=' + Date.now());
    const d = await r.json();
    const videos = (d.videos || []).slice(0, 9);
    el.innerHTML = videos.length
      ? videos.map(v => `<article class="video-item"><div class="video-type">${v.tipo || 'VIDEO'} · BOCA OFICIAL</div><h3>${String(v.titulo || 'Video de Boca').replace(/[&<>]/g, '')}</h3><p>${String(v.descripcion || 'Resumen, entrevista o contenido multimedia.').replace(/[&<>]/g, '')}</p><a href="${v.link || '#'}" target="_blank" rel="noopener">VER VIDEO →</a></article>`).join('')
      : '<p>No hay videos nuevos disponibles todavía.</p>';
  } catch (e) { console.error(e); }
}

/* ---------- Arranque ---------- */
initClock();
initHamburger();
initTilt();
loadHomeData();
loadPosicionesData();
loadMultimediaVideos();

if (document.getElementById('ticker')) setInterval(loadHomeData, 30 * 60 * 1000);
if (document.getElementById('agendaContainer')) setInterval(loadPosicionesData, 30 * 60 * 1000);
